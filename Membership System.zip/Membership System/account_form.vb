﻿Public Class account_form

    Private Sub btn_toggle_Click(sender As Object, e As EventArgs) Handles btn_toggle.Click
        If btn_toggle.Text = "Unlock" Then
            tbox_username.Enabled = True
            tbox_password.Enabled = True
            tbox_firstname.Enabled = True
            tbox_lastname.Enabled = True
            btn_toggle.Text = "Lock"
            btn_update.Visible = True
            btn_delete.Visible = False
        ElseIf btn_toggle.Text = "Lock" Then
            tbox_username.Enabled = False
            tbox_password.Enabled = False
            tbox_firstname.Enabled = False
            tbox_lastname.Enabled = False
            btn_toggle.Text = "Unlock"
            btn_update.Visible = False
            btn_delete.Visible = True
        End If
    End Sub

    Private Sub btn_back_Click(sender As Object, e As EventArgs) Handles btn_back.Click
        account_list.Show()
        Me.Close()
    End Sub

    Private Sub btn_delete_Click(sender As Object, e As EventArgs) Handles btn_delete.Click
        If MessageBox.Show("Are you sure you want to delete this record?", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = Windows.Forms.DialogResult.Yes Then
            Dim sql As String = "DELETE FROM admin WHERE [admin_id] = " & admin_id
            Dim conn = New OleDb.OleDbConnection(dbSource)
            Try
                conn.Open()
                Dim cmd = New OleDb.OleDbCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                MessageBox.Show("Deleted the record", "", MessageBoxButtons.OK, MessageBoxIcon.Hand)
            Catch ex As Exception
                MessageBox.Show("Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                conn.Close()
                account_list.Show()
                Me.Close()
            End Try
        End If
    End Sub

    Private Sub account_form_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim sql As String = "SELECT * FROM admin WHERE admin_id = " & admin_id
        Dim dAdapter As OleDb.OleDbDataAdapter
        Dim dSet As New DataSet
        Dim conn = New OleDb.OleDbConnection(dbSource)
        conn.Open()
        dAdapter = New OleDb.OleDbDataAdapter(sql, conn)
        dAdapter.Fill(dSet, "admin")
        conn.Close()
        tbox_username.Text = dSet.Tables(0).Rows(0).Item(1).ToString
        tbox_password.Text = dSet.Tables(0).Rows(0).Item(2).ToString
        tbox_firstname.Text = dSet.Tables(0).Rows(0).Item(3).ToString
        tbox_lastname.Text = dSet.Tables(0).Rows(0).Item(4).ToString
    End Sub

    Private Sub btn_update_Click(sender As Object, e As EventArgs) Handles btn_update.Click
        Dim username, password, firstname, lastname As String
        Dim conn = New OleDb.OleDbConnection(dbSource)
        Try
            username = tbox_username.Text
            password = tbox_password.Text
            firstname = tbox_firstname.Text
            lastname = tbox_lastname.Text
            Dim sql As String = "UPDATE admin SET username = '" & Trim(username) & "', [password] = '" & Trim(password) & "', firstname = '" & Trim(firstname) & "', lastname = '" & Trim(lastname) & "' WHERE admin_id = " & admin_id
            conn.Open()
            Dim cmd = New OleDb.OleDbCommand(sql, conn)
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            MessageBox.Show("Successfully Update a record", "", MessageBoxButtons.OK, MessageBoxIcon.Information)
            account_list.Show()
            Me.Close()
        Catch ex As Exception
            MessageBox.Show("Error", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            conn.Close()
        End Try
    End Sub
End Class