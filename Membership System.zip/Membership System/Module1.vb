﻿Imports System
Imports System.Data
Imports System.Data.OleDb
Imports Microsoft.VisualBasic.ApplicationServices
Imports System.Data.SqlClient

Module Module1
    Public admin_firstname As String
    Public admin_id As String
    Public fee_id As String
    Public stud_id As String
    Public dbSource As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\issm_db.accdb"
End Module
