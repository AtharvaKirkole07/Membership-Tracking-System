﻿Public Class account_list

    Private Sub account_list_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim sql As String = "SELECT * FROM admin ORDER BY lastname ASC"
        Dim conn = New OleDb.OleDbConnection(dbSource)
        Dim cmd As OleDb.OleDbCommand
        Dim data_read As OleDb.OleDbDataReader
        conn.Open()
        cmd = New OleDb.OleDbCommand(sql, conn)
        data_read = cmd.ExecuteReader
        If data_read.HasRows Then
            While data_read.Read
                Dim newitem As New ListViewItem()
                newitem.Text = data_read.GetValue(0).ToString
                newitem.SubItems.Add(data_read.GetValue(1).ToString)
                newitem.SubItems.Add(data_read.GetValue(2).ToString)
                newitem.SubItems.Add(data_read.GetValue(3).ToString)
                newitem.SubItems.Add(data_read.GetValue(4).ToString)
                ListView1.Items.Add(newitem)
            End While
        End If
        conn.Close()
    End Sub

    Private Sub ListView1_DoubleClick(sender As Object, e As EventArgs) Handles ListView1.DoubleClick
        If ListView1.SelectedItems.Count > 0 Then
            admin_id = ListView1.SelectedItems(0).SubItems(0).Text
            account_form.Show()
            Me.Close()
        End If
    End Sub

    Private Sub tbox_search_TextChanged(sender As Object, e As EventArgs) Handles tbox_search.TextChanged
        ListView1.Items.Clear()
        Dim sql = "SELECT * FROM admin WHERE (username LIKE '%" & tbox_search.Text & "%' OR firstname LIKE '%" & tbox_search.Text & "%') ORDER BY lastname ASC"
        Dim conn = New OleDb.OleDbConnection(dbSource)
        Dim cmd As OleDb.OleDbCommand
        Dim data_read As OleDb.OleDbDataReader
        conn.Open()
        cmd = New OleDb.OleDbCommand(sql, conn)
        data_read = cmd.ExecuteReader
        If data_read.HasRows Then
            While data_read.Read
                Dim newitem As New ListViewItem()
                newitem.Text = data_read.GetValue(0).ToString
                newitem.SubItems.Add(data_read.GetValue(1).ToString)
                newitem.SubItems.Add(data_read.GetValue(2).ToString)
                newitem.SubItems.Add(data_read.GetValue(3).ToString)
                newitem.SubItems.Add(data_read.GetValue(4).ToString)
                ListView1.Items.Add(newitem)
            End While
        End If
        conn.Close()
    End Sub
End Class