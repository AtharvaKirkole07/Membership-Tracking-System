﻿Public Class student_main
    Private Sub btn_login_Click(sender As Object, e As EventArgs) Handles btn_login.Click
        Dim studid As String
        studid = tbox_studid.Text
        Dim sql As String = "SELECT * FROM member WHERE stud_id = '" & studid & "'"
        Dim conn = New OleDb.OleDbConnection(dbSource)
        Dim dAdapter As OleDb.OleDbDataAdapter
        Dim dSet As New DataSet
        conn.Open()
        dAdapter = New OleDb.OleDbDataAdapter(sql, conn)
        dAdapter.Fill(dSet, "member")
        conn.Close()
        If dSet.Tables(0).Rows.Count > 0 Then
            If MessageBox.Show("Login Successfully!", "", MessageBoxButtons.OK, MessageBoxIcon.Information) = Windows.Forms.DialogResult.OK Then
                stud_id = studid
                student_mainscreen.Show()
                student_form.Show()
                Me.Close()
            End If
        Else
            MessageBox.Show("Student ID does not exist!", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            tbox_studid.Text = ""
        End If
    End Sub
End Class