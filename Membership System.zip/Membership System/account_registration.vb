﻿Public Class account_registration
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim conn = New OleDb.OleDbConnection(dbSource)
        Dim dAdapter As OleDb.OleDbDataAdapter
        Dim dSet As New DataSet
        conn.Open()
        Dim username, password, firstname, lastname, sql, sql1 As String
        username = tbox_username.Text
        password = tbox_password.Text
        firstname = tbox_firstname.Text
        lastname = tbox_lastname.Text
        sql1 = "SELECT * FROM admin WHERE username = '" & username & "'"
        dAdapter = New OleDb.OleDbDataAdapter(sql1, conn)
        dAdapter.Fill(dSet, "admin")
        If username = "" Or password = "" Or firstname = "" Then
            MsgBox("Please fill the required field")
            tbox_username.BackColor = Color.Red
            tbox_password.BackColor = Color.Red
            tbox_firstname.BackColor = Color.Red
        Else
            If dSet.Tables(0).Rows.Count > 0 Then
                MsgBox("Username is already taken")
                tbox_username.BackColor = Color.Yellow
                tbox_firstname.BackColor = Color.White
                tbox_password.BackColor = Color.White
            Else
                Try
                    sql = "INSERT INTO admin (username, [password], firstname, lastname) VALUES ('" & username & "', '" & password & "', '" & firstname & "', '" & lastname & "') "
                    Dim cmd = New OleDb.OleDbCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    tbox_username.Clear()
                    tbox_username.BackColor = Color.White
                    tbox_password.Clear()
                    tbox_password.BackColor = Color.White
                    tbox_firstname.Clear()
                    tbox_firstname.BackColor = Color.White
                    tbox_lastname.Clear()
                    MsgBox("Record was saved")
                Catch ex As Exception
                    MsgBox("Error")
                Finally
                    conn.Close()
                End Try
            End If
        End If
    End Sub
End Class