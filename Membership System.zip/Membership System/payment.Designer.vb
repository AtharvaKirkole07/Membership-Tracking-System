﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class payment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.tbox_balance = New System.Windows.Forms.TextBox()
        Me.lbl_balance = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cbox_status = New System.Windows.Forms.ComboBox()
        Me.tbox_sem = New System.Windows.Forms.TextBox()
        Me.tbox_year = New System.Windows.Forms.TextBox()
        Me.btn_confirm = New System.Windows.Forms.Button()
        Me.tbox_pay = New System.Windows.Forms.TextBox()
        Me.Label = New System.Windows.Forms.Label()
        Me.tbox_price = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.tbox_lastname = New System.Windows.Forms.TextBox()
        Me.tbox_firstname = New System.Windows.Forms.TextBox()
        Me.tbox_studid = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 18.0!)
        Me.Label1.ForeColor = System.Drawing.SystemColors.Control
        Me.Label1.Location = New System.Drawing.Point(219, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(226, 27)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Payment / Accounts"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.tbox_balance)
        Me.GroupBox1.Controls.Add(Me.lbl_balance)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.cbox_status)
        Me.GroupBox1.Controls.Add(Me.tbox_sem)
        Me.GroupBox1.Controls.Add(Me.tbox_year)
        Me.GroupBox1.Controls.Add(Me.btn_confirm)
        Me.GroupBox1.Controls.Add(Me.tbox_pay)
        Me.GroupBox1.Controls.Add(Me.Label)
        Me.GroupBox1.Controls.Add(Me.tbox_price)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.ComboBox1)
        Me.GroupBox1.Controls.Add(Me.tbox_lastname)
        Me.GroupBox1.Controls.Add(Me.tbox_firstname)
        Me.GroupBox1.Controls.Add(Me.tbox_studid)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.Control
        Me.GroupBox1.Location = New System.Drawing.Point(34, 79)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(583, 251)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Details"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(56, 82)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(54, 18)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "Name:"
        '
        'tbox_balance
        '
        Me.tbox_balance.Enabled = False
        Me.tbox_balance.Location = New System.Drawing.Point(328, 179)
        Me.tbox_balance.Name = "tbox_balance"
        Me.tbox_balance.Size = New System.Drawing.Size(100, 26)
        Me.tbox_balance.TabIndex = 15
        Me.tbox_balance.Visible = False
        '
        'lbl_balance
        '
        Me.lbl_balance.AutoSize = True
        Me.lbl_balance.Location = New System.Drawing.Point(260, 182)
        Me.lbl_balance.Name = "lbl_balance"
        Me.lbl_balance.Size = New System.Drawing.Size(69, 18)
        Me.lbl_balance.TabIndex = 14
        Me.lbl_balance.Text = "Balance:"
        Me.lbl_balance.Visible = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(325, 36)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(56, 18)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "Status:"
        '
        'cbox_status
        '
        Me.cbox_status.Enabled = False
        Me.cbox_status.FormattingEnabled = True
        Me.cbox_status.Items.AddRange(New Object() {"Balance", "Available"})
        Me.cbox_status.Location = New System.Drawing.Point(387, 33)
        Me.cbox_status.Name = "cbox_status"
        Me.cbox_status.Size = New System.Drawing.Size(121, 26)
        Me.cbox_status.TabIndex = 2
        '
        'tbox_sem
        '
        Me.tbox_sem.Enabled = False
        Me.tbox_sem.Location = New System.Drawing.Point(483, 126)
        Me.tbox_sem.Name = "tbox_sem"
        Me.tbox_sem.Size = New System.Drawing.Size(66, 26)
        Me.tbox_sem.TabIndex = 11
        '
        'tbox_year
        '
        Me.tbox_year.Enabled = False
        Me.tbox_year.Location = New System.Drawing.Point(378, 126)
        Me.tbox_year.Name = "tbox_year"
        Me.tbox_year.Size = New System.Drawing.Size(98, 26)
        Me.tbox_year.TabIndex = 10
        '
        'btn_confirm
        '
        Me.btn_confirm.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btn_confirm.Location = New System.Drawing.Point(474, 182)
        Me.btn_confirm.Name = "btn_confirm"
        Me.btn_confirm.Size = New System.Drawing.Size(75, 26)
        Me.btn_confirm.TabIndex = 5
        Me.btn_confirm.Text = "Confirm"
        Me.btn_confirm.UseVisualStyleBackColor = True
        '
        'tbox_pay
        '
        Me.tbox_pay.Location = New System.Drawing.Point(116, 179)
        Me.tbox_pay.Name = "tbox_pay"
        Me.tbox_pay.Size = New System.Drawing.Size(121, 26)
        Me.tbox_pay.TabIndex = 4
        '
        'Label
        '
        Me.Label.AutoSize = True
        Me.Label.Location = New System.Drawing.Point(36, 182)
        Me.Label.Name = "Label"
        Me.Label.Size = New System.Drawing.Size(77, 18)
        Me.Label.TabIndex = 7
        Me.Label.Text = "Payment: "
        '
        'tbox_price
        '
        Me.tbox_price.Enabled = False
        Me.tbox_price.Location = New System.Drawing.Point(243, 126)
        Me.tbox_price.Name = "tbox_price"
        Me.tbox_price.Size = New System.Drawing.Size(129, 26)
        Me.tbox_price.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(62, 129)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 18)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Fees:"
        '
        'ComboBox1
        '
        Me.ComboBox1.Enabled = False
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(116, 126)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 26)
        Me.ComboBox1.TabIndex = 3
        '
        'tbox_lastname
        '
        Me.tbox_lastname.Enabled = False
        Me.tbox_lastname.Location = New System.Drawing.Point(328, 79)
        Me.tbox_lastname.Name = "tbox_lastname"
        Me.tbox_lastname.Size = New System.Drawing.Size(190, 26)
        Me.tbox_lastname.TabIndex = 3
        '
        'tbox_firstname
        '
        Me.tbox_firstname.Enabled = False
        Me.tbox_firstname.Location = New System.Drawing.Point(117, 79)
        Me.tbox_firstname.Name = "tbox_firstname"
        Me.tbox_firstname.Size = New System.Drawing.Size(193, 26)
        Me.tbox_firstname.TabIndex = 2
        '
        'tbox_studid
        '
        Me.tbox_studid.Location = New System.Drawing.Point(117, 33)
        Me.tbox_studid.Name = "tbox_studid"
        Me.tbox_studid.Size = New System.Drawing.Size(146, 26)
        Me.tbox_studid.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(27, 36)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(84, 18)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Student ID:"
        '
        'payment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Maroon
        Me.ClientSize = New System.Drawing.Size(653, 361)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "payment"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.TopMost = True
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents btn_confirm As System.Windows.Forms.Button
    Friend WithEvents tbox_pay As System.Windows.Forms.TextBox
    Friend WithEvents Label As System.Windows.Forms.Label
    Friend WithEvents tbox_price As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents tbox_lastname As System.Windows.Forms.TextBox
    Friend WithEvents tbox_firstname As System.Windows.Forms.TextBox
    Friend WithEvents tbox_studid As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents tbox_sem As System.Windows.Forms.TextBox
    Friend WithEvents tbox_year As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cbox_status As System.Windows.Forms.ComboBox
    Friend WithEvents tbox_balance As System.Windows.Forms.TextBox
    Friend WithEvents lbl_balance As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
End Class
