﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class admin_main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.tbox_username = New System.Windows.Forms.TextBox()
        Me.tbox_password = New System.Windows.Forms.TextBox()
        Me.lbl_username = New System.Windows.Forms.Label()
        Me.lbl_password = New System.Windows.Forms.Label()
        Me.lbl_administrator = New System.Windows.Forms.Label()
        Me.btn_login = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'tbox_username
        '
        Me.tbox_username.Location = New System.Drawing.Point(165, 121)
        Me.tbox_username.Name = "tbox_username"
        Me.tbox_username.Size = New System.Drawing.Size(171, 26)
        Me.tbox_username.TabIndex = 0
        '
        'tbox_password
        '
        Me.tbox_password.Location = New System.Drawing.Point(165, 178)
        Me.tbox_password.Name = "tbox_password"
        Me.tbox_password.Size = New System.Drawing.Size(171, 26)
        Me.tbox_password.TabIndex = 1
        Me.tbox_password.UseSystemPasswordChar = True
        '
        'lbl_username
        '
        Me.lbl_username.AutoSize = True
        Me.lbl_username.ForeColor = System.Drawing.SystemColors.Control
        Me.lbl_username.Location = New System.Drawing.Point(75, 124)
        Me.lbl_username.Name = "lbl_username"
        Me.lbl_username.Size = New System.Drawing.Size(84, 18)
        Me.lbl_username.TabIndex = 2
        Me.lbl_username.Text = "Username:"
        '
        'lbl_password
        '
        Me.lbl_password.AutoSize = True
        Me.lbl_password.ForeColor = System.Drawing.SystemColors.Control
        Me.lbl_password.Location = New System.Drawing.Point(75, 182)
        Me.lbl_password.Name = "lbl_password"
        Me.lbl_password.Size = New System.Drawing.Size(82, 18)
        Me.lbl_password.TabIndex = 3
        Me.lbl_password.Text = "Password:"
        '
        'lbl_administrator
        '
        Me.lbl_administrator.AutoSize = True
        Me.lbl_administrator.Font = New System.Drawing.Font("Arial", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_administrator.ForeColor = System.Drawing.SystemColors.Control
        Me.lbl_administrator.Location = New System.Drawing.Point(116, 38)
        Me.lbl_administrator.Name = "lbl_administrator"
        Me.lbl_administrator.Size = New System.Drawing.Size(202, 36)
        Me.lbl_administrator.TabIndex = 4
        Me.lbl_administrator.Text = "Administrator"
        '
        'btn_login
        '
        Me.btn_login.Location = New System.Drawing.Point(78, 249)
        Me.btn_login.Name = "btn_login"
        Me.btn_login.Size = New System.Drawing.Size(258, 29)
        Me.btn_login.TabIndex = 6
        Me.btn_login.Text = "Login"
        Me.btn_login.UseVisualStyleBackColor = True
        '
        'admin_main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Maroon
        Me.ClientSize = New System.Drawing.Size(426, 361)
        Me.Controls.Add(Me.btn_login)
        Me.Controls.Add(Me.lbl_administrator)
        Me.Controls.Add(Me.lbl_password)
        Me.Controls.Add(Me.lbl_username)
        Me.Controls.Add(Me.tbox_password)
        Me.Controls.Add(Me.tbox_username)
        Me.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "admin_main"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Information System Society Membership"
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents tbox_username As System.Windows.Forms.TextBox
    Friend WithEvents tbox_password As System.Windows.Forms.TextBox
    Friend WithEvents lbl_username As System.Windows.Forms.Label
    Friend WithEvents lbl_password As System.Windows.Forms.Label
    Friend WithEvents lbl_administrator As System.Windows.Forms.Label
    Friend WithEvents btn_login As System.Windows.Forms.Button
End Class
