﻿Public Class student_mainscreen

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        mainscreen.Show()
        student_main.Show()
        Me.Close()
        student_form.Close()
    End Sub

    Private Sub student_mainscreen_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Me.Visible = True Then
            mainscreen.Close()
        End If
    End Sub
End Class