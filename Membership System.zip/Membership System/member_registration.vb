﻿Imports System.IO
Public Class member_registration

    Private Sub btn_upload_Click(sender As Object, e As EventArgs) Handles btn_upload.Click
        OpenFileDialog1.Filter = "image file (*.jpg, *.bmp, *.png) | *.jpg; *.bmp; *.png | all files (*.*) | *.* "
        If OpenFileDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            PictureBox1.Image = Image.FromFile(OpenFileDialog1.FileName)
        End If

    End Sub

    Private Sub tbox_studid_KeyPress(sender As Object, e As KeyPressEventArgs) Handles tbox_studid.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            MessageBox.Show("Please enter numbers only", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            e.Handled = True
        End If
    End Sub

    Private Sub btn_clear_Click(sender As Object, e As EventArgs) Handles btn_clear.Click
        tbox_studid.Clear()
        tbox_firstname.Clear()
        tbox_middlename.Clear()
        tbox_lastname.Clear()
        tbox_contactno.Clear()
        cbox_gender.ResetText()
        cbox_year.ResetText()
        cbox_section.ResetText()
        tbox_address.Clear()
        PictureBox1.Image = Nothing
    End Sub

    Private Sub btn_save_Click(sender As Object, e As EventArgs) Handles btn_save.Click
        Dim stud_id, firstname, middlename, lastname, contactno, gender, year, section, address As String
        stud_id = tbox_studid.Text
        firstname = tbox_firstname.Text
        middlename = tbox_middlename.Text
        lastname = tbox_lastname.Text
        contactno = tbox_contactno.Text
        gender = cbox_gender.Text
        section = cbox_section.Text
        year = cbox_year.Text
        address = tbox_address.Text
        If Not stud_id = "" Then
            If stud_id.Length.Equals(8) Then
                Dim conn = New OleDb.OleDbConnection(dbSource)
                Dim dAdapter As OleDb.OleDbDataAdapter
                Dim dSet As New DataSet
                Dim sql1 As String = "SELECT * FROM member WHERE stud_id = '" & tbox_studid.Text & "'"
                conn.Open()
                dAdapter = New OleDb.OleDbDataAdapter(sql1, conn)
                dAdapter.Fill(dSet, "admin")
                conn.Close()
                If dSet.Tables(0).Rows.Count > 0 Then
                    MessageBox.Show("Student ID is already registered", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Else
                    Try
                        conn.Open()
                        Dim byImages As Byte()
                        Dim ms As New System.IO.MemoryStream
                        Dim bmimage As New Bitmap(PictureBox1.Image)
                        bmimage.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg)
                        byImages = ms.ToArray()
                        ms.Close()
                        Dim sql As String = "INSERT INTO `member` (stud_id, firstname, middlename, lastname, contactno, gender, [year], [section], address, picture) VALUES ('" & stud_id & "', '" & firstname & "', '" & middlename & "', '" & lastname & "', '" & contactno & "', '" & gender & "', '" & year & "', '" & section & "', '" & address & "', @image)"
                        Dim cmd As New OleDb.OleDbCommand(sql, conn)
                        MessageBox.Show("Successfully Saved a record", "", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        cmd.Parameters.AddWithValue("@image", byImages)
                        cmd.ExecuteNonQuery()
                        cmd.Dispose()
                        tbox_studid.Clear()
                        tbox_firstname.Clear()
                        tbox_middlename.Clear()
                        tbox_lastname.Clear()
                        tbox_contactno.Clear()
                        cbox_gender.ResetText()
                        cbox_year.ResetText()
                        cbox_section.ResetText()
                        tbox_address.Clear()
                        PictureBox1.Image = Nothing
                    Catch ex As Exception
                        MessageBox.Show("Error", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Finally
                        conn.Close()
                    End Try
                End If
            Else
                MessageBox.Show("Student ID must be 8 digits", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End If
        Else
            MessageBox.Show("Studen ID is required!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub
End Class