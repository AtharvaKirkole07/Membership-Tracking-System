﻿Public Class admin_main
    Private Sub btn_login_Click(sender As Object, e As EventArgs) Handles btn_login.Click
        Dim username As String
        Dim password As String
        Dim query As String
        Dim dAdapter As OleDb.OleDbDataAdapter
        Dim dSet As New DataSet
        username = tbox_username.Text
        password = tbox_password.Text
        If Not (username = "" Or password = "") Then
            Dim conn = New OleDb.OleDbConnection(dbSource)
            query = "SELECT * from admin WHERE username = '" & Trim(username) & "' AND password = '" & Trim(password) & "'"
            conn.Open()
            dAdapter = New OleDb.OleDbDataAdapter(query, conn)
            conn.Close()
            dAdapter.Fill(dSet, "admin")
            If dSet.Tables(0).Rows.Count > 0 Then
                Me.Close()
                admin_firstname = (dSet.Tables(0).Rows(0).Item(3))
                MsgBox("Welcome " & admin_firstname)
                admin_mainscreen.Show()
                mainscreen.Close()
                tbox_username.Text = ""
                tbox_password.Text = ""
            Else
                MessageBox.Show("Username not found", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
                tbox_username.BackColor = Color.Yellow
                tbox_password.BackColor = Color.Yellow
            End If
        Else
            tbox_username.BackColor = Color.Red
            tbox_password.BackColor = Color.Red
        End If
    End Sub

End Class