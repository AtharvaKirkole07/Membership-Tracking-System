﻿Public Class fee_form
    Private Sub fee_form_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim sql As String = "SELECT * FROM fee WHERE fee_id = " & fee_id
        Dim conn = New OleDb.OleDbConnection(dbSource)
        Dim dAdapter As OleDb.OleDbDataAdapter
        Dim dSet As New DataSet
        conn.Open()
        dAdapter = New OleDb.OleDbDataAdapter(sql, conn)
        dAdapter.Fill(dSet, "fee")
        conn.Close()
        tbox_title.Text = dSet.Tables(0).Rows(0).Item(1).ToString
        tbox_price.Text = dSet.Tables(0).Rows(0).Item(2).ToString
        tbox_ay.Text = dSet.Tables(0).Rows(0).Item(3).ToString
        cbox_sem.Text = dSet.Tables(0).Rows(0).Item(4).ToString
    End Sub

    Private Sub btn_toggle_Click(sender As Object, e As EventArgs) Handles btn_toggle.Click
        If btn_toggle.Text = "Unlock" Then
            tbox_title.Enabled = True
            tbox_price.Enabled = True
            tbox_ay.Enabled = True
            cbox_sem.Enabled = True
            btn_toggle.Text = "Lock"
            btn_delete.Visible = False
            btn_update.Visible = True
        Else
            If btn_toggle.Text = "Lock" Then
                tbox_title.Enabled = False
                tbox_price.Enabled = False
                tbox_ay.Enabled = False
                cbox_sem.Enabled = False
                btn_toggle.Text = "Unlock"
                btn_delete.Visible = True
                btn_update.Visible = False
            End If
        End If
    End Sub

    Private Sub btn_delete_Click(sender As Object, e As EventArgs) Handles btn_delete.Click
       If MessageBox.Show("Are you sure you want to delete this record?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = Windows.Forms.DialogResult.Yes Then
            Dim sql As String = "DELETE FROM fee WHERE [fee_id] = " & fee_id
            Dim conn = New OleDb.OleDbConnection(dbSource)
            Try
                conn.Open()
                Dim cmd = New OleDb.OleDbCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                MessageBox.Show("Successfully Deleted a record", "", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Catch ex As Exception
                MessageBox.Show("Error", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                conn.Close()
                fee_list.Show()
                Me.Close()
            End Try
        End If
    End Sub

    Private Sub tbox_price_KeyPress(sender As Object, e As KeyPressEventArgs) Handles tbox_price.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            MessageBox.Show("Please enter numbers only", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            e.Handled = True
        End If
    End Sub

    Private Sub btn_back_Click(sender As Object, e As EventArgs) Handles btn_back.Click
        fee_list.Show()
        Me.Close()
    End Sub

    Private Sub btn_update_Click(sender As Object, e As EventArgs) Handles btn_update.Click
        Dim title As String = tbox_title.Text
        Dim price As String = tbox_price.Text
        Dim ay As String = tbox_ay.Text
        Dim sem As String = cbox_sem.Text
        Dim ay_total As String = ay + 1
        Dim sql As String = "UPDATE fee SET detail = '" & Trim(title) & "', price = '" & Trim(price) & "', [ay] = '" & ay & " - " & ay_total & "', sem = '" & sem & "' WHERE [fee_id] = " & fee_id
        Dim conn = New OleDb.OleDbConnection(dbSource)
        Try
            conn.Open()
            Dim cmd = New OleDb.OleDbCommand(sql, conn)
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            MessageBox.Show("Successfully Updated a record", "", MessageBoxButtons.OK, MessageBoxIcon.Information)
            fee_list.Show()
            Me.Close()
        Catch ex As Exception
            MessageBox.Show("Error", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            conn.Close()
        End Try
    End Sub

End Class