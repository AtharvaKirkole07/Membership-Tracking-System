﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class member_form
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btn_back = New System.Windows.Forms.Button()
        Me.btn_toggle = New System.Windows.Forms.Button()
        Me.btn_delete = New System.Windows.Forms.Button()
        Me.btn_update = New System.Windows.Forms.Button()
        Me.tbox_address = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.tbox_contactno = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.cbox_section = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cbox_year = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cbox_gender = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btn_change = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.tbox_lastname = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.tbox_middlename = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.tbox_firstname = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tbox_studid = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btn_back)
        Me.GroupBox1.Controls.Add(Me.btn_toggle)
        Me.GroupBox1.Controls.Add(Me.btn_delete)
        Me.GroupBox1.Controls.Add(Me.btn_update)
        Me.GroupBox1.Controls.Add(Me.tbox_address)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.tbox_contactno)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.cbox_section)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.cbox_year)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.cbox_gender)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.btn_change)
        Me.GroupBox1.Controls.Add(Me.PictureBox1)
        Me.GroupBox1.Controls.Add(Me.tbox_lastname)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.tbox_middlename)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.tbox_firstname)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.tbox_studid)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.Control
        Me.GroupBox1.Location = New System.Drawing.Point(27, 32)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(727, 311)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Registration Form"
        '
        'btn_back
        '
        Me.btn_back.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btn_back.Location = New System.Drawing.Point(630, 263)
        Me.btn_back.Name = "btn_back"
        Me.btn_back.Size = New System.Drawing.Size(75, 27)
        Me.btn_back.TabIndex = 14
        Me.btn_back.Text = "Back"
        Me.btn_back.UseVisualStyleBackColor = True
        '
        'btn_toggle
        '
        Me.btn_toggle.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btn_toggle.Location = New System.Drawing.Point(448, 263)
        Me.btn_toggle.Name = "btn_toggle"
        Me.btn_toggle.Size = New System.Drawing.Size(75, 27)
        Me.btn_toggle.TabIndex = 12
        Me.btn_toggle.Text = "Unlock"
        Me.btn_toggle.UseVisualStyleBackColor = True
        '
        'btn_delete
        '
        Me.btn_delete.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btn_delete.Location = New System.Drawing.Point(542, 263)
        Me.btn_delete.Name = "btn_delete"
        Me.btn_delete.Size = New System.Drawing.Size(75, 27)
        Me.btn_delete.TabIndex = 13
        Me.btn_delete.Text = "Delete"
        Me.btn_delete.UseVisualStyleBackColor = True
        '
        'btn_update
        '
        Me.btn_update.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btn_update.Location = New System.Drawing.Point(542, 263)
        Me.btn_update.Name = "btn_update"
        Me.btn_update.Size = New System.Drawing.Size(75, 27)
        Me.btn_update.TabIndex = 13
        Me.btn_update.Text = "Update"
        Me.btn_update.UseVisualStyleBackColor = True
        Me.btn_update.Visible = False
        '
        'tbox_address
        '
        Me.tbox_address.Enabled = False
        Me.tbox_address.Location = New System.Drawing.Point(354, 177)
        Me.tbox_address.Name = "tbox_address"
        Me.tbox_address.Size = New System.Drawing.Size(137, 26)
        Me.tbox_address.TabIndex = 9
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(277, 180)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(71, 18)
        Me.Label9.TabIndex = 16
        Me.Label9.Text = "Address:"
        '
        'tbox_contactno
        '
        Me.tbox_contactno.Enabled = False
        Me.tbox_contactno.Location = New System.Drawing.Point(114, 218)
        Me.tbox_contactno.Name = "tbox_contactno"
        Me.tbox_contactno.Size = New System.Drawing.Size(147, 26)
        Me.tbox_contactno.TabIndex = 5
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(14, 221)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(90, 18)
        Me.Label8.TabIndex = 15
        Me.Label8.Text = "Contact No:"
        '
        'cbox_section
        '
        Me.cbox_section.Enabled = False
        Me.cbox_section.FormattingEnabled = True
        Me.cbox_section.Items.AddRange(New Object() {"A", "B", "C", "D"})
        Me.cbox_section.Location = New System.Drawing.Point(354, 129)
        Me.cbox_section.Name = "cbox_section"
        Me.cbox_section.Size = New System.Drawing.Size(137, 26)
        Me.cbox_section.TabIndex = 8
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(283, 132)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(65, 18)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Section:"
        '
        'cbox_year
        '
        Me.cbox_year.Enabled = False
        Me.cbox_year.FormattingEnabled = True
        Me.cbox_year.Items.AddRange(New Object() {"1st", "2nd", "3rd", "4th"})
        Me.cbox_year.Location = New System.Drawing.Point(354, 83)
        Me.cbox_year.Name = "cbox_year"
        Me.cbox_year.Size = New System.Drawing.Size(137, 26)
        Me.cbox_year.TabIndex = 7
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(305, 86)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(43, 18)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Year:"
        '
        'cbox_gender
        '
        Me.cbox_gender.Enabled = False
        Me.cbox_gender.FormattingEnabled = True
        Me.cbox_gender.Items.AddRange(New Object() {"Male", "Female"})
        Me.cbox_gender.Location = New System.Drawing.Point(355, 36)
        Me.cbox_gender.Name = "cbox_gender"
        Me.cbox_gender.Size = New System.Drawing.Size(136, 26)
        Me.cbox_gender.TabIndex = 6
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(284, 40)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(64, 18)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Gender:"
        '
        'btn_change
        '
        Me.btn_change.Enabled = False
        Me.btn_change.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.btn_change.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btn_change.Location = New System.Drawing.Point(585, 179)
        Me.btn_change.Name = "btn_change"
        Me.btn_change.Size = New System.Drawing.Size(73, 23)
        Me.btn_change.TabIndex = 11
        Me.btn_change.Text = "Change"
        Me.btn_change.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Gainsboro
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox1.Location = New System.Drawing.Point(542, 25)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(163, 150)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 7
        Me.PictureBox1.TabStop = False
        '
        'tbox_lastname
        '
        Me.tbox_lastname.Enabled = False
        Me.tbox_lastname.Location = New System.Drawing.Point(114, 174)
        Me.tbox_lastname.Name = "tbox_lastname"
        Me.tbox_lastname.Size = New System.Drawing.Size(147, 26)
        Me.tbox_lastname.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(23, 177)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(81, 18)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Lastname:"
        '
        'tbox_middlename
        '
        Me.tbox_middlename.Enabled = False
        Me.tbox_middlename.Location = New System.Drawing.Point(114, 129)
        Me.tbox_middlename.Name = "tbox_middlename"
        Me.tbox_middlename.Size = New System.Drawing.Size(147, 26)
        Me.tbox_middlename.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(7, 132)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(98, 18)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Middlename:"
        '
        'tbox_firstname
        '
        Me.tbox_firstname.Enabled = False
        Me.tbox_firstname.Location = New System.Drawing.Point(114, 83)
        Me.tbox_firstname.Name = "tbox_firstname"
        Me.tbox_firstname.Size = New System.Drawing.Size(147, 26)
        Me.tbox_firstname.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(23, 86)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(82, 18)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Firstname:"
        '
        'tbox_studid
        '
        Me.tbox_studid.Enabled = False
        Me.tbox_studid.Location = New System.Drawing.Point(114, 37)
        Me.tbox_studid.Name = "tbox_studid"
        Me.tbox_studid.Size = New System.Drawing.Size(147, 26)
        Me.tbox_studid.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(23, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(84, 18)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Student ID:"
        '
        'member_form
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Maroon
        Me.ClientSize = New System.Drawing.Size(780, 375)
        Me.Controls.Add(Me.GroupBox1)
        Me.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "member_form"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.TopMost = True
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents btn_delete As System.Windows.Forms.Button
    Friend WithEvents btn_update As System.Windows.Forms.Button
    Friend WithEvents tbox_address As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents tbox_contactno As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents cbox_section As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cbox_year As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents cbox_gender As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btn_change As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents tbox_lastname As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents tbox_middlename As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents tbox_firstname As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents tbox_studid As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btn_back As System.Windows.Forms.Button
    Friend WithEvents btn_toggle As System.Windows.Forms.Button
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
End Class
