﻿Public Class student_form

    Private Sub student_form_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim sql As String = "SELECT * FROM member WHERE stud_id = '" & stud_id & "'"
        Dim conn = New OleDb.OleDbConnection(dbSource)
        Dim dAdapter As OleDb.OleDbDataAdapter
        Dim dSet As New DataSet
        Dim arrImage() As Byte
        Dim myMs As New IO.MemoryStream
        conn.Open()
        dAdapter = New OleDb.OleDbDataAdapter(sql, conn)
        dAdapter.Fill(dSet, "member")
        conn.Close()
        tbox_studid.Text = dSet.Tables(0).Rows(0).Item(0).ToString
        tbox_firstname.Text = dSet.Tables(0).Rows(0).Item(1).ToString
        tbox_middlename.Text = dSet.Tables(0).Rows(0).Item(2).ToString
        tbox_lastname.Text = dSet.Tables(0).Rows(0).Item(3).ToString
        tbox_contactno.Text = dSet.Tables(0).Rows(0).Item(7).ToString
        cbox_gender.Text = dSet.Tables(0).Rows(0).Item(8).ToString
        cbox_year.Text = dSet.Tables(0).Rows(0).Item(4).ToString
        cbox_section.Text = dSet.Tables(0).Rows(0).Item(5).ToString
        tbox_address.Text = dSet.Tables(0).Rows(0).Item(6).ToString
        If Not IsDBNull(dSet.Tables(0).Rows(0).Item(9)) Then
            arrImage = dSet.Tables(0).Rows(0).Item(9)
            For Each ar As Byte In arrImage
                myMs.WriteByte(ar)
            Next
            PictureBox1.Image = System.Drawing.Image.FromStream(myMs)
        End If
        Dim sql1 = "SELECT * FROM [transaction] INNER JOIN fee ON transaction.transact_details = fee.fee_id WHERE mem_id = '" & stud_id & "' And status = 'Balance'"
        Dim cmd As OleDb.OleDbCommand
        Dim data_read As OleDb.OleDbDataReader
        Dim tBal As Double
        tBal = 0
        Try
            conn.Open()
            cmd = New OleDb.OleDbCommand(sql1, conn)
            data_read = cmd.ExecuteReader
            If data_read.HasRows Then
                While data_read.Read
                    Dim newitem As New ListViewItem()
                    newitem.Text = data_read.GetValue(7).ToString
                    newitem.SubItems.Add(data_read.GetValue(9).ToString)
                    newitem.SubItems.Add(data_read.GetValue(10).ToString)
                    newitem.SubItems.Add(data_read.GetValue(4).ToString)
                    ListView1.Items.Add(newitem)
                    tBal = Val(tBal) + Val(data_read.GetValue(4).ToString)
                End While
            End If
            tbox_balance.Text = tBal
        Catch ex As Exception
            MessageBox.Show("Error", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            conn.Close()
        End Try
        'Dim sql2 As String = "SELECT SUM(balance) as totalVal FROM [transaction] where status = 'Balance' and mem_id = '" & stud_id & "' "
        'Dim cmd2 As OleDb.OleDbCommand
        'Dim data_read2 As OleDb.OleDbDataReader
        'Try
        '    conn.Open()
        '    cmd2 = New OleDb.OleDbCommand(sql2, conn)
        '    data_read2 = cmd2.ExecuteReader
        '    If data_read2.HasRows Then
        '        data_read2.Read()
        '        Dim totalBal As String = data_read2("totalVal")
        '        tbox_balance.Text = totalBal
        '    Else
        '        tbox_balance.Text = 0

        '    End If
        'Catch ex As Exception
        '    MessageBox.Show("Error" & ex.Message & " " & sql2, "", MessageBoxButtons.OK, MessageBoxIcon.Error)
        'Finally
        '    conn.Close()
        'End Try
    End Sub
End Class