﻿Imports System.IO
Public Class member_form
    Private Sub btn_delete_Click(sender As Object, e As EventArgs) Handles btn_delete.Click
        If MessageBox.Show("Are you sure you want to delete this record?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = Windows.Forms.DialogResult.Yes Then
            Dim sql = "DELETE FROM member WHERE [stud_id] = '" & stud_id & "'"
            Dim conn = New OleDb.OleDbConnection(dbSource)
            Try
                conn.Open()
                Dim cmd = New OleDb.OleDbCommand(sql, conn)
                cmd.ExecuteNonQuery()
                cmd.Dispose()
                MessageBox.Show("Successfully Deleted a record", "", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Catch ex As Exception
                MessageBox.Show("Error", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                conn.Close()
                member_list.Show()
                Me.Close()
            End Try
        End If
    End Sub

    Private Sub btn_update_Click(sender As Object, e As EventArgs) Handles btn_update.Click
        Dim stud_id, firstname, middlename, lastname, contactno, gender, year, section, address As String
        stud_id = tbox_studid.Text
        firstname = tbox_firstname.Text
        middlename = tbox_middlename.Text
        lastname = tbox_lastname.Text
        contactno = tbox_contactno.Text
        gender = cbox_gender.Text
        section = cbox_section.Text
        year = cbox_year.Text
        address = tbox_address.Text
        Dim conn = New OleDb.OleDbConnection(dbSource)
        Dim cmd As OleDb.OleDbCommand
        Dim sql As String = "UPDATE member SET stud_id = '" & stud_id & "', firstname = '" & firstname & "', middlename = '" & middlename & "', lastname = '" & lastname & "', contactno = '" & contactno & "', gender = '" & gender & "', [year] = '" & year & "', [section] = '" & section & "', address = '" & address & "', picture = @image WHERE stud_id = '" & stud_id & "'"
        Try
            conn.Open()
            Dim byImages As Byte()
            Dim ms As New System.IO.MemoryStream
            Dim bmimage As New Bitmap(PictureBox1.Image)
            bmimage.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg)
            byImages = ms.ToArray()
            ms.Close()
            cmd = New OleDb.OleDbCommand(sql, conn)
            cmd.Parameters.AddWithValue("@image", byImages)
            cmd.ExecuteNonQuery()
            cmd.Dispose()
            MessageBox.Show("Successfully Updated a member", "", MessageBoxButtons.OK, MessageBoxIcon.Information)
            member_list.Show()
            Me.Close()
        Catch ex As Exception
            MessageBox.Show("Error", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            conn.Close()
        End Try
        
    End Sub

    Private Sub member_form_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim sql As String = "SELECT * FROM member WHERE stud_id = '" & stud_id & "'"
        Dim conn = New OleDb.OleDbConnection(dbSource)
        Dim dAdapter As OleDb.OleDbDataAdapter
        Dim dSet As New DataSet
        Dim arrImage() As Byte
        Dim myMs As New IO.MemoryStream
        conn.Open()
        dAdapter = New OleDb.OleDbDataAdapter(sql, conn)
        dAdapter.Fill(dSet, "member")
        tbox_studid.Text = dSet.Tables(0).Rows(0).Item(0).ToString
        tbox_firstname.Text = dSet.Tables(0).Rows(0).Item(1).ToString
        tbox_middlename.Text = dSet.Tables(0).Rows(0).Item(2).ToString
        tbox_lastname.Text = dSet.Tables(0).Rows(0).Item(3).ToString
        tbox_contactno.Text = dSet.Tables(0).Rows(0).Item(7).ToString
        cbox_gender.Text = dSet.Tables(0).Rows(0).Item(8).ToString
        cbox_year.Text = dSet.Tables(0).Rows(0).Item(4).ToString
        cbox_section.Text = dSet.Tables(0).Rows(0).Item(5).ToString
        tbox_address.Text = dSet.Tables(0).Rows(0).Item(6).ToString
        If Not IsDBNull(dSet.Tables(0).Rows(0).Item(9)) Then
            arrImage = dSet.Tables(0).Rows(0).Item(9)
            For Each ar As Byte In arrImage
                myMs.WriteByte(ar)
            Next
            PictureBox1.Image = System.Drawing.Image.FromStream(myMs)
        End If
        conn.Close()
    End Sub

    Private Sub btn_toggle_Click(sender As Object, e As EventArgs) Handles btn_toggle.Click
        If btn_toggle.Text = "Unlock" Then
            tbox_firstname.Enabled = True
            tbox_studid.Enabled = True
            tbox_middlename.Enabled = True
            tbox_lastname.Enabled = True
            tbox_contactno.Enabled = True
            cbox_gender.Enabled = True
            cbox_year.Enabled = True
            cbox_section.Enabled = True
            tbox_address.Enabled = True
            btn_delete.Visible = False
            btn_update.Visible = True
            btn_toggle.Text = "Lock"
            btn_change.Enabled = True
        Else
            If btn_toggle.Text = "Lock" Then
                tbox_firstname.Enabled = False
                tbox_middlename.Enabled = False
                tbox_lastname.Enabled = False
                tbox_contactno.Enabled = False
                cbox_gender.Enabled = False
                tbox_studid.Enabled = False
                cbox_year.Enabled = False
                cbox_section.Enabled = False
                tbox_address.Enabled = False
                btn_delete.Visible = True
                btn_update.Visible = False
                btn_toggle.Text = "Unlock"
                btn_change.Enabled = False
            End If
        End If
    End Sub

    Private Sub btn_back_Click(sender As Object, e As EventArgs) Handles btn_back.Click
        member_list.Show()
        Me.Close()
    End Sub

    Private Sub btn_change_Click(sender As Object, e As EventArgs) Handles btn_change.Click
        OpenFileDialog1.Filter = "image file (*.jpg, *.bmp, *.png) | *.jpg; *.bmp; *.png | all files (*.*) | *.* "
        If OpenFileDialog1.ShowDialog <> Windows.Forms.DialogResult.Cancel Then
            PictureBox1.Image = Image.FromFile(OpenFileDialog1.FileName)
        End If
    End Sub


End Class