﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class student_main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn_login = New System.Windows.Forms.Button()
        Me.lbl_administrator = New System.Windows.Forms.Label()
        Me.lbl_studid = New System.Windows.Forms.Label()
        Me.tbox_studid = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btn_login
        '
        Me.btn_login.Location = New System.Drawing.Point(86, 245)
        Me.btn_login.Name = "btn_login"
        Me.btn_login.Size = New System.Drawing.Size(258, 29)
        Me.btn_login.TabIndex = 12
        Me.btn_login.Text = "Login"
        Me.btn_login.UseVisualStyleBackColor = True
        '
        'lbl_administrator
        '
        Me.lbl_administrator.AutoSize = True
        Me.lbl_administrator.Font = New System.Drawing.Font("Arial", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_administrator.ForeColor = System.Drawing.SystemColors.Control
        Me.lbl_administrator.Location = New System.Drawing.Point(156, 60)
        Me.lbl_administrator.Name = "lbl_administrator"
        Me.lbl_administrator.Size = New System.Drawing.Size(124, 36)
        Me.lbl_administrator.TabIndex = 11
        Me.lbl_administrator.Text = "Student"
        '
        'lbl_studid
        '
        Me.lbl_studid.AutoSize = True
        Me.lbl_studid.ForeColor = System.Drawing.SystemColors.Control
        Me.lbl_studid.Location = New System.Drawing.Point(83, 154)
        Me.lbl_studid.Name = "lbl_studid"
        Me.lbl_studid.Size = New System.Drawing.Size(84, 18)
        Me.lbl_studid.TabIndex = 9
        Me.lbl_studid.Text = "Student ID:"
        '
        'tbox_studid
        '
        Me.tbox_studid.Location = New System.Drawing.Point(173, 151)
        Me.tbox_studid.Name = "tbox_studid"
        Me.tbox_studid.Size = New System.Drawing.Size(171, 26)
        Me.tbox_studid.TabIndex = 7
        '
        'student_main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Maroon
        Me.ClientSize = New System.Drawing.Size(426, 361)
        Me.Controls.Add(Me.btn_login)
        Me.Controls.Add(Me.lbl_administrator)
        Me.Controls.Add(Me.lbl_studid)
        Me.Controls.Add(Me.tbox_studid)
        Me.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "student_main"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "student_main"
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btn_login As System.Windows.Forms.Button
    Friend WithEvents lbl_administrator As System.Windows.Forms.Label
    Friend WithEvents lbl_studid As System.Windows.Forms.Label
    Friend WithEvents tbox_studid As System.Windows.Forms.TextBox
End Class
