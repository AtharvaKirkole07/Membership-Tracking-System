﻿Public Class frm_splashscreen

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ProgressBar1.Increment(1)
        If ProgressBar1.Value = 100 Then
            Timer1.Stop()
            Me.Hide()
            mainscreen.Show()
            admin_main.Show()
        End If
    End Sub

End Class
