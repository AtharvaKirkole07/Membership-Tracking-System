﻿Public Class fee_registration

    Private Sub btn_save_Click(sender As Object, e As EventArgs) Handles btn_save.Click
        Dim title, price, ay, sem As String
        title = tbox_title.Text
        price = tbox_price.Text
        ay = tbox_ay.Text
        sem = cbox_sem.Text
        If tbox_title.Text = "" Or tbox_price.Text = "" Or tbox_ay.Text = "" Or cbox_sem.Text = "" Then
            MessageBox.Show("Please Complete the form", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        Else
            Dim ay_total As String = ay + 1
            Dim conn = New OleDb.OleDbConnection(dbSource)
            Dim sql1 As String = "SELECT * FROM fee WHERE detail = '" & title & "' And [ay] = '" & ay & " - " & ay_total & "' And sem = '" & sem & "'"
            Dim dAdapter As OleDb.OleDbDataAdapter
            Dim dSet As New DataSet
            conn.Open()
            dAdapter = New OleDb.OleDbDataAdapter(sql1, conn)
            dAdapter.Fill(dSet, "fee")
            If dSet.Tables(0).Rows.Count > 0 Then
                MessageBox.Show("Warning! Record already exist", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                tbox_title.Clear()
                tbox_price.Clear()
                tbox_ay.Clear()
                cbox_sem.ResetText()
            Else
                Try
                    Dim sql As String = "INSERT INTO fee (detail, [price], [ay], sem) VALUES ('" & title & "', '" & price & "', '" & ay & " - " & ay_total & "', '" & sem & "')"
                    Dim cmd = New OleDb.OleDbCommand(sql, conn)
                    cmd.ExecuteNonQuery()
                    cmd.Dispose()
                    MessageBox.Show("Successfully Saved a record", "", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    tbox_title.Clear()
                    tbox_price.Clear()
                    tbox_ay.Clear()
                    cbox_sem.ResetText()
                Catch ex As Exception
                    MessageBox.Show("Error", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Finally
                    conn.Close()
                End Try
            End If
        End If
    End Sub

    Private Sub tbox_price_KeyPress(sender As Object, e As KeyPressEventArgs)
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            MessageBox.Show("Please enter numbers only", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            e.Handled = True
        End If
    End Sub

    Private Sub tbox_ay_KeyPress(sender As Object, e As KeyPressEventArgs) Handles tbox_ay.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            MessageBox.Show("Please enter numbers only", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            e.Handled = True
        End If
    End Sub

    Private Sub tbox_price_KeyPress_1(sender As Object, e As KeyPressEventArgs) Handles tbox_price.KeyPress
        If Asc(e.KeyChar) <> 13 AndAlso Asc(e.KeyChar) <> 8 AndAlso Not IsNumeric(e.KeyChar) Then
            MessageBox.Show("Please enter numbers only", "", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            e.Handled = True
        End If
    End Sub
End Class