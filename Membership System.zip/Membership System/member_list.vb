﻿Public Class member_list

    Private Sub member_list_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim conn = New OleDb.OleDbConnection(dbSource)
        Dim sql As String = "SELECT * FROM member ORDER BY lastname ASC"
        Dim cmd As OleDb.OleDbCommand
        Dim data_read As OleDb.OleDbDataReader
        conn.Open()
        cmd = New OleDb.OleDbCommand(sql, conn)
        data_read = cmd.ExecuteReader
        If data_read.HasRows Then
            While data_read.Read
                Dim newitem As New ListViewItem()
                newitem.Text = data_read.GetValue(0).ToString
                newitem.SubItems.Add(data_read.GetValue(1).ToString)
                newitem.SubItems.Add(data_read.GetValue(2).ToString)
                newitem.SubItems.Add(data_read.GetValue(3).ToString)
                newitem.SubItems.Add(data_read.GetValue(4).ToString)
                newitem.SubItems.Add(data_read.GetValue(5).ToString)
                newitem.SubItems.Add(data_read.GetValue(8).ToString)
                newitem.SubItems.Add(data_read.GetValue(7).ToString)
                newitem.SubItems.Add(data_read.GetValue(6).ToString)
                ListView1.Items.Add(newitem)
            End While
        End If
        conn.Close()
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles tbox_search.TextChanged
        ListView1.Items.Clear()
        Dim sql = "SELECT * FROM member WHERE (stud_id LIKE '%" & tbox_search.Text & "%' Or firstname LIKE '%" & tbox_search.Text & "%' Or lastname LIKE '%" & tbox_search.Text & "%')"
        Dim conn = New OleDb.OleDbConnection(dbSource)
        Dim cmd As OleDb.OleDbCommand
        Dim data_read As OleDb.OleDbDataReader
        conn.Open()
        cmd = New OleDb.OleDbCommand(sql, conn)
        data_read = cmd.ExecuteReader
        If data_read.HasRows Then
            While data_read.Read
                Dim newitem As New ListViewItem()
                newitem.Text = data_read.GetValue(0).ToString
                newitem.SubItems.Add(data_read.GetValue(1).ToString)
                newitem.SubItems.Add(data_read.GetValue(2).ToString)
                newitem.SubItems.Add(data_read.GetValue(3).ToString)
                newitem.SubItems.Add(data_read.GetValue(4).ToString)
                newitem.SubItems.Add(data_read.GetValue(5).ToString)
                newitem.SubItems.Add(data_read.GetValue(8).ToString)
                newitem.SubItems.Add(data_read.GetValue(7).ToString)
                newitem.SubItems.Add(data_read.GetValue(6).ToString)
                ListView1.Items.Add(newitem)
            End While
        End If
        conn.Close()
    End Sub

    Private Sub ListView1_DoubleClick(sender As Object, e As EventArgs) Handles ListView1.DoubleClick
        If ListView1.SelectedItems.Count > 0 Then
            stud_id = ListView1.SelectedItems(0).SubItems(0).Text
            member_form.Show()
            Me.Close()
        End If
    End Sub
End Class