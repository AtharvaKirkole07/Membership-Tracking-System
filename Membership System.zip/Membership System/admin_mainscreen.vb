﻿Public Class admin_mainscreen

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        mainscreen.Show()
        admin_main.Show()
        If mainscreen.Visible = True Then
            account_registration.Close()
            account_list.Close()
            member_registration.Close()
            account_form.Close()
            fee_registration.Close()
            fee_list.Close()
            fee_form.Close()
            Me.Close()
            member_list.Close()
            member_form.Close()
            payment.Close()
        End If
    End Sub

    Private Sub RegistrationToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles RegistrationToolStripMenuItem1.Click
        account_registration.Show()
        If account_registration.Visible = True Then
            account_list.Close()
            member_registration.Close()
            account_form.Close()
            fee_registration.Close()
            fee_list.Close()
            member_list.Close()
            fee_form.Close()
            member_form.Close()
            payment.Close()
        End If
    End Sub

    Private Sub ListToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ListToolStripMenuItem.Click
        account_list.Show()
        If account_list.Visible = True Then
            account_registration.Close()
            account_form.Close()
            member_registration.Close()
            fee_registration.Close()
            fee_list.Close()
            fee_form.Close()
            member_list.Close()
            member_form.Close()
            payment.Close()
        End If
    End Sub

    Private Sub admin_mainscreen_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ToolStripMenuItem1.Text = admin_firstname
    End Sub

    Private Sub MenuStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub

    Private Sub RegistrationToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles RegistrationToolStripMenuItem2.Click
        member_registration.Show()
        If member_registration.Visible = True Then
            account_registration.Close()
            account_list.Close()
            account_form.Close()
            fee_registration.Close()
            fee_list.Close()
            fee_form.Close()
            member_list.Close()
            member_form.Close()
            payment.Close()
        End If
    End Sub

    Private Sub RegistrationToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles RegistrationToolStripMenuItem3.Click
        fee_registration.Show()
        If fee_registration.Visible = True Then
            account_registration.Close()
            account_list.Close()
            account_form.Close()
            member_registration.Close()
            fee_list.Close()
            fee_form.Close()
            member_list.Close()
            member_form.Close()
            payment.Close()
        End If
    End Sub

    Private Sub ListToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles ListToolStripMenuItem2.Click
        fee_list.Show()
        If fee_list.Visible = True Then
            account_registration.Close()
            account_list.Close()
            account_form.Close()
            member_registration.Close()
            fee_registration.Close()
            fee_form.Close()
            member_list.Close()
            member_form.Close()
            payment.Close()
        End If
    End Sub

    Private Sub ListToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ListToolStripMenuItem1.Click
        member_list.Show()
        If member_list.Visible = True Then
            account_registration.Close()
            account_list.Close()
            account_form.Close()
            member_registration.Close()
            fee_registration.Close()
            fee_form.Close()
            fee_list.Close()
            member_form.Close()
            payment.Close()
        End If
    End Sub

    Private Sub ToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem2.Click
        payment.Show()
        If payment.Visible = True Then
            account_registration.Close()
            account_list.Close()
            account_form.Close()
            member_registration.Close()
            fee_registration.Close()
            fee_form.Close()
            fee_list.Close()
            member_form.Close()
            member_list.Close()
        End If
    End Sub
End Class